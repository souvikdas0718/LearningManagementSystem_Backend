import json

def lambda_handler(event, context):
    # TODO implement
    print(event)
    print("-----------------------------------------")
    print(event['currentIntent']['slots']['OrganizationNames'])
    org = event['currentIntent']['slots']['OrganizationNames']
    try:
        connection = pymysql.connect(host='serverless-project.cwatpkmdgenk.us-east-1.rds.amazonaws.com',
                                 user='serverless', password='serverless', db='serverless', charset='utf8mb4')
        with connection.cursor() as cursor:
            sql = "SELECT name FROM `userStatus` where `instituteName`=%s and `status`= 'online' "
            cursor.execute(sql, (instituteName))
            result = cursor.fetchall()
            print(result)
            return {     
                   "sessionAttributes": {
                      "key1": "value1",
                      "key2": "value2"
                    },   
                    "dialogAction": {     
                        "type": "Close",
                        "fulfillmentState": "Fulfilled",
                        "message": {       
                           "contentType": "PlainText",
                           "content": org
                        },    
                     } 
                };
    except Exception as e:
        return {     
   "sessionAttributes": {
      "key1": "value1",
      "key2": "value2"
    },   
    "dialogAction": {     
        "type": "Close",
        "fulfillmentState": "Failed",
        "message": {       
           "contentType": "PlainText",
           "content": "Error"
        },    
     } 
};
    


# exports.handler = async (event) => {
#     console.log(event)
#     console.log("-----------------------------------------")
#     console.log(event.currentIntent.slots.OrganizationNames)
#     const org = event.currentIntent.slots.OrganizationNames;
#     // TODO implement
#     const response = {     
#   "sessionAttributes": {
#       "key1": "value1",
#       "key2": "value2"
#     },   
#     "dialogAction": {     
#         "type": "Close",
#         "fulfillmentState": "Fulfilled",
#         "message": {       
#           "contentType": "PlainText",
#           "content": org
#         },    
#      } 
# };
#     // const response = {
#     //     statusCode: 200,
#     //     body: JSON.stringify('Hello from Lambda!'),
#     // };
#     return response;
# };
