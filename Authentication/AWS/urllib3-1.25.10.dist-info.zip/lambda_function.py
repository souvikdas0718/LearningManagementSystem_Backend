import json
import requests
import boto3
import botocore.exceptions
import hmac
import hashlib
import base64

USER_POOL_ID = 'us-east-1_DUJ1OFR0U'
CLIENT_ID = '75q99f08ahuqof4eqbh98rt61v'
CLIENT_SECRET = '1g364uimbpa0im65u7dds1rocldtq6447iior2barrohgf05rcau'


def get_secret_hash(username):
    msg = username + CLIENT_ID
    dig = hmac.new(str(CLIENT_SECRET).encode(
        'utf-8'), msg=str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    d2 = base64.b64encode(dig).decode()
    return d2


def lambda_handler(event, context):
    print(event)
    data = eval(event['body'])
    print(data)
    
    try:
        client = boto3.client('cognito-idp')
        auth_data = { 'USERNAME':data['email'] , 'PASSWORD':data['password'], "SECRET_HASH": get_secret_hash(data['email']) }
        resp = client.initiate_auth(AuthFlow='USER_PASSWORD_AUTH', AuthParameters=auth_data, ClientId=CLIENT_ID)
        print('resp:', resp)
    except client.exceptions.NotAuthorizedException as e:
        print("err",e)
        return {'statusCode': 500, 'headers': {'Content-Type': 'application/json'}, "body": json.dumps({'Error':str(e)})}
    except Exception as e:
        print("err1",e)
        return {'statusCode': 500, 'headers': {'Content-Type': 'application/json'}, "body": json.dumps({'Error':str(e)})}
    else:
        data1 = json.dumps({'email': data['email'], 'question': data['question'], 'answer': data['answer']})
        response = requests.post('', data=data1, headers={'Content-Type': 'application/json'})
        print(response.text)
        return {
        "body": json.dumps('msg': str(response.text))
        }

    
#--------------------------------------------------------------
# CODE FOR DELETE COGNITO DATA
#--------------------------------------------------------------
    # client = boto3.client('cognito-idp')
    # response = client.list_users(UserPoolId=USER_POOL_ID, AttributesToGet=[])
    # print(response)
    # for i in response['Users']:
    #     print(i['Username'])
    #     response1 = client.admin_delete_user(UserPoolId=USER_POOL_ID,Username=str(i['Username'])            )
    # response = client.list_users(UserPoolId=USER_POOL_ID, AttributesToGet=[])
    # print(len(response['Users']))
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }