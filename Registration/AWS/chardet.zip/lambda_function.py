import json
import pymysql.cursors

def lambda_handler(event, context):
	print(event)
	data = event['body']
	data = eval(data)
	return {
        'statusCode': 200,
        'headers': { 'Content-Type': 'application/json' },
        'body': json.dumps(data)
    }

connection = pymysql.connect(host='serverless-project.cwatpkmdgenk.us-east-1.rds.amazonaws.com',
                             user='serverless',
                             password='serverless',
                             db='serverless',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

# def lambda_handler(event, context):
# 	print(event)
# 	data = event['body']
# 	data = eval(data)
#     try:
#         with connection.cursor() as cursor:
#         # Create a new record
#         sql = "INSERT INTO `user` (`name`, `email`, `password`, `instituteName`) VALUES (%s, %s, %s, %s)"
#         cursor.execute(sql, (data['name'], data['email'], data['password'], data['instituteName']))
#         connection.commit()
#         body = {"msg": "Success"}
#     except Exception as e:
#         body = {"error": str(e)}
#     finally:
#         connection.close()
# 	return {
#         'statusCode': 200,
#         'headers': { 'Content-Type': 'application/json' },
#         'body': json.dumps(body)
#     }

try:
    with connection.cursor() as cursor:
        sql = "SELECT count(`email`) FROM `user` WHERE `email`=%s"
        cursor.execute(sql, ('emai1l',))
        count = cursor.fetchone()["count(`email`)"]
        if count > 0:
            body = {'msg': 'User already exist'}
        else:
            sql = "INSERT INTO `user` (`name`, `email`, `password`, `instituteName`) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, ('name', 'email1', 'password', 'instituteName'))
            connection.commit()
            body = {"msg": "Success"}
except Exception as e:
    body = {"error": str(e)}
finally:
    print(body)
    connection.close()


#     with connection.cursor() as cursor:
#         # Read a single record
#         sql = "SELECT `id`, `password` FROM `users` WHERE `email`=%s"
#         cursor.execute(sql, ('webmaster@python.org',))
#         result = cursor.fetchone()
#         print(result)
        
# finally:
#     connection.close()